import { configureStore, createSlice } from "@reduxjs/toolkit";
import { cartData } from "./cartData";

import user from "./userStore";
import stock from "./stockStore";

let cart = createSlice({
  name: "cart",
  initialState: cartData,
});

export const store = configureStore({
  reducer: {
    user: user.reducer,
    stock: stock.reducer,
    cart: cart.reducer,
  },
});
