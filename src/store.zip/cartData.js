export const cartData = [
  {
    id: 1,
    title: "14K/18K 허니 벌집2 헥사곤 심플 반지",
    img: "image1.jpg",
    price: "185000",
    category: "new",
    discount: "5",
    count: 1,
  },
  {
    id: 6,
    title: "14k/18k 티얼스 라운드 큐빅 여성 체인 목걸이",
    img: "image6.jpg",
    price: "310000",
    category: "top",
    discount: "5",
    count: 3,
  },
];
